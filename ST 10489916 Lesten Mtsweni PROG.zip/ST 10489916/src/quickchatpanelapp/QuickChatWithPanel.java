/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quickchatpanelapp;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

// Mtsweni Lesten ST10489916
public class QuickChatWithPanel {
    private static String registeredUsername;
    private static String registeredPassword;
    private static String registeredPhone;
    private static boolean isLoggedIn = false;

    private static class Message {
        String id;
        String content;
        String token;

        Message(String id, String content, String token) {
            this.id = id;
            this.content = content;
            this.token = token;
        }
    }

    private static final List<Message> messages = new ArrayList<>();

    public static void main(String[] args) {
        registerUser();
        loginUser();
        mainMenu();
    }

    private static void registerUser() {
        while (true) {
            JPanel panel = new JPanel(new GridLayout(10, 6));
            JTextField usernameField = new JTextField();
            JPasswordField passwordField = new JPasswordField();
            JTextField phoneField = new JTextField();

            panel.add(new JLabel("Username:"));
            panel.add(usernameField);
            panel.add(new JLabel("Password:"));
            panel.add(passwordField);
            panel.add(new JLabel("Phone (+countrycode+number):"));
            panel.add(phoneField);

            int result = JOptionPane.showConfirmDialog(null, panel, "Register", JOptionPane.OK_CANCEL_OPTION);

            if (result == JOptionPane.OK_OPTION) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String phone = phoneField.getText();

                if (!checkUsername(username)) {
                    showMessage("Username is not correctly formated,please ensure that your username contains an underscore and is no more than five characters long");
                    return;
                }

                if (!checkPasswordComplexity(password)) {
                    showMessage("password is not correctly formatted please ensure that the password contains atleast 8 characters "
                        + "ensure that the password contains atleast 8 characters,a capital letter and a special character.");
                    return;
                }

                if (!checkCellPhoneNumber(phone)) {
                    showMessage("Cellphone number incorrectly formatted or does not contain international code");
                    return;
                }

                registeredUsername = username;
                registeredPassword = password;
                registeredPhone = phone;

                showMessage("Registration successful");
                break;
            } else {
                System.exit(0);
            }
        }
    }

    private static void loginUser() {
        while (!isLoggedIn) {
            JPanel panel = new JPanel(new GridLayout(10, 6));
            JTextField usernameField = new JTextField();
            JPasswordField passwordField = new JPasswordField();

            panel.add(new JLabel("Username:"));
            panel.add(usernameField);
            panel.add(new JLabel("Password:"));
            panel.add(passwordField);

            int result = JOptionPane.showConfirmDialog(null, panel, "Login", JOptionPane.OK_CANCEL_OPTION);

            if (result == JOptionPane.OK_OPTION) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
                    isLoggedIn = true;
                    showMessage("Welcome to quickChat");
                } else {
                    showMessage("Invalid credentials. Try again.");
                }
            } else {
                System.exit(0);
            }
        }
    }

    private static void mainMenu() {
        while (true) {
            String input = JOptionPane.showInputDialog("""
                    Select an option:
                    1) Send messages
                    2) Show recently sent messages
                    3) Quit
                    """);

            if (input == null) continue;

            switch (input) {
                case "1" -> sentMessages();
                case "2" -> showMessage("Coming soon");
                case "3" -> {
                    showMessage("Goodbye ");
                    System.exit(0);
                }
                default -> showMessage("Invalid option. Please choose 1, 2 or 3.");
            }
        }
    }

    private static void sentMessages() {
        int messageCount;
        try {
            String countInput = JOptionPane.showInputDialog("How many messages would you like to send?");
            if (countInput == null) return;
            messageCount = Integer.parseInt(countInput);
        } catch (NumberFormatException e) {
            showMessage("Please enter a valid number.");
            return;
        }
        // using a for loop to enter message
        for (int i = 0; i < messageCount; i++) {
            String recipient = JOptionPane.showInputDialog("Enter recipient number (+27XXXXXXXXX):");
            String content = JOptionPane.showInputDialog("Enter message " + (i + 1) + ":");
            String[] options = {"Send", "Disregard", "Store for later"};
            Component menuFrame = null;
        int choice = JOptionPane.showOptionDialog(menuFrame, "Choose an action", "Message Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
        

            if (content != null && !content.trim().isEmpty()) {
                String id = UUID.randomUUID().toString();
                String token = checkMessageID();
                messages.add(new Message(id, content, token));
                showMessage("Message saved.\nID: " + id + "\nToken: " + token);
            }
        }
    }
    // message id for tracking
    private static String checkMessageID() {
        Random rand = new Random();
        StringBuilder number = new StringBuilder();
        while (number.length() < 10) {
            number.append(rand.nextInt(10));
        }
        return number.toString();
    }
    // validate username
    private static boolean checkUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }
    // validate password
    private static boolean checkPasswordComplexity(String password) {
        return password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$");
    }
    // validate cell number
    private static boolean checkCellPhoneNumber(String phone) {
        return phone.matches("^\\+\\d{1,3}\\d{1,10}$");
    }

    private static void showMessage(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
}
